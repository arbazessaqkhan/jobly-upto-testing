import JobsPage from "@/modules/jobs/components/JobsPage";

export default function Page() {
  return <JobsPage />;
}