/**
 * @file src/modules/jobs/__tests__/JobFormModal.test.tsx
 */
import React from "react";
import {fireEvent, render, screen, waitFor} from "@testing-library/react";
import "@testing-library/jest-dom";
import JobFormModal from "../components/JobFormModal";
import {CreateJobDto, JobDto} from "../jobs.service";
import {LocationEnum} from "@/modules/jobs/schema";

describe("JobFormModal component", () => {
    const defaultValues: CreateJobDto = {
        title: "",
        description: "",
        salary: 0,
        is_active: true,
        location: "Remote",
    };

    it("renders modal with default values", () => {
        render(
            <JobFormModal
                defaultValues={defaultValues}
                editJob={null}
                onSubmit={jest.fn()}
            />
        );

        // The modal might not be visible until triggered,
        // but we can still check if form fields exist in the DOM.
        expect(screen.getByLabelText("Title")).toBeInTheDocument();
        expect(screen.getByLabelText("Description")).toBeInTheDocument();
        expect(screen.getByLabelText("Location")).toBeInTheDocument();
        expect(screen.getByLabelText("Salary")).toBeInTheDocument();
        expect(screen.getByLabelText("Is Active")).toBeInTheDocument();
    });

    it("calls onSubmit with correct form data when creating a job", async () => {
        const mockOnSubmit = jest.fn();

        render(
            <JobFormModal
                defaultValues={defaultValues}
                editJob={null}
                onSubmit={mockOnSubmit}
            />
        );

        // Fill out the form
        fireEvent.change(screen.getByLabelText("Title"), {
            target: { value: "My New Job" },
        });
        fireEvent.change(screen.getByLabelText("Description"), {
            target: { value: "Doing stuff" },
        });
        fireEvent.change(screen.getByLabelText("Salary"), {
            target: { value: "1234" },
        });
        fireEvent.change(screen.getByLabelText("Location"), {
            target: { value: "Hybrid" },
        });

        // Submit
        fireEvent.click(screen.getByRole("button", { name: /Save/i, hidden: true }));

        await waitFor(() => {
            expect(mockOnSubmit).toHaveBeenCalledTimes(1);
        });

        const submittedData = mockOnSubmit.mock.calls[0][0];
        expect(submittedData).toEqual({
            title: "My New Job",
            description: "Doing stuff",
            salary: 1234,
            is_active: true,
            location: LocationEnum.Enum.Hybrid,
        });
    });


    it("shows edit modal title when editJob is set", () => {
        const editJob: JobDto = {
            id: 1,
            title: "Edited Title",
            description: "Edited Desc",
            salary: 9999,
            is_active: false,
            location: LocationEnum.Enum.Remote,
            created_at: new Date(),
            updated_at: new Date(),
        };

        render(
            <JobFormModal
                defaultValues={defaultValues}
                editJob={editJob}
                onSubmit={jest.fn()}
            />
        );

        expect(screen.getByText("Edit Job")).toBeInTheDocument();
    });

    it("resets and clears form fields after submit", async () => {
        const mockOnSubmit = jest.fn();
        const editJob: CreateJobDto = {
            title: "Test Title",
            description: "Test Description",
            salary: 5000,
            is_active: false,
            location: LocationEnum.Enum.Hybrid,
        };

        render(
            <JobFormModal
                defaultValues={editJob}
                editJob={null}
                onSubmit={mockOnSubmit}
            />
        );

        fireEvent.change(screen.getByLabelText("Title"), {
            target: { value: "Edited Title" },
        });
        fireEvent.change(screen.getByLabelText("Description"), {
            target: { value: "Edited Description" },
        });
        fireEvent.change(screen.getByLabelText("Salary"), {
            target: { value: "10000" },
        });
        fireEvent.change(screen.getByLabelText("Location"), {
            target: { value: "Remote" },
        });
        fireEvent.click(screen.getByLabelText("Is Active"));

        fireEvent.click(screen.getByRole("button", { name: /Save/i, hidden: true }));

        await waitFor(() => {
            expect(mockOnSubmit).toHaveBeenCalledTimes(1);
        });

        expect(screen.getByLabelText("Title")).toHaveValue("Test Title");
        expect(screen.getByLabelText("Description")).toHaveValue("Test Description");
        expect(screen.getByLabelText("Salary")).toHaveValue(5000);
        expect(screen.getByLabelText("Location")).toHaveValue("Hybrid");
        expect(screen.getByLabelText("Is Active")).not.toBeChecked();
    });

    it("displays validation errors for required fields and ensures error text is red", async () => {
        const mockOnSubmit = jest.fn();

        render(
            <JobFormModal
                defaultValues={defaultValues}
                editJob={null}
                onSubmit={mockOnSubmit}
            />
        );
        fireEvent.click(screen.getByRole("button", { name: /Save/i, hidden: true }));
        const titleError = await screen.findByText("Title is required");
        const descError = await screen.findByText("Description is required");
        expect(titleError).toBeInTheDocument();
        expect(descError).toBeInTheDocument();
        expect(mockOnSubmit).not.toHaveBeenCalled();
        expect(titleError).toHaveClass("error-message")
        expect(titleError).toHaveStyle("color: red");
    });
});
