/**
 * @file src/modules/jobs/__tests__/JobsTable.test.tsx
 */
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import JobsTable from "../components/JobsTable";
import { JobDto } from "../jobs.service";

describe("JobsTable component", () => {
    const mockJobs: JobDto[] = [
        {
            id: 1,
            title: "Job One",
            description: "Description One",
            salary: 1000,
            is_active: false,
            location: "Remote",
            created_at: new Date("2023-01-01"),
            updated_at: new Date("2023-01-02"),
        },
        {
            id: 2,
            title: "Job Two",
            description: "Description Two",
            salary: 2000,
            is_active: false,
            location: "Onsite",
            created_at: new Date("2023-01-03"),
            updated_at: new Date("2023-01-04"),
        },
    ];

    // Ensure window.confirm exists in our test environment
    beforeAll(() => {
        if (!window.confirm) {
            window.confirm = jest.fn();
        }
    });

    afterEach(() => {
        jest.restoreAllMocks();
    });

    it("renders rows with correct data", () => {
        render(<JobsTable jobs={mockJobs} onEdit={jest.fn()} onDelete={jest.fn()} />);

        // Use test IDs to verify that the correct text is rendered
        expect(screen.getByTestId("job-title-1")).toHaveTextContent("Job One");
        expect(screen.getByTestId("job-title-2")).toHaveTextContent("Job Two");
        expect(screen.getByTestId("job-active-1")).toHaveTextContent("No");
        expect(screen.getByTestId("job-active-2")).toHaveTextContent("No");
    });

    it("calls onEdit when Edit button is clicked", () => {
        const onEditMock = jest.fn();
        render(<JobsTable jobs={mockJobs} onEdit={onEditMock} onDelete={jest.fn()} />);

        const editButton = screen.getByTestId("edit-button-1");
        fireEvent.click(editButton);

        expect(onEditMock).toHaveBeenCalledWith(mockJobs[0]);
    });

    it("calls onDelete when Delete button is clicked and user confirms", () => {
        const onDeleteMock = jest.fn();
        // Override window.confirm to simulate a confirm action
        jest.spyOn(window, "confirm").mockImplementation(() => true);

        render(
            <JobsTable
                jobs={mockJobs}
                onEdit={jest.fn()}
                onDelete={onDeleteMock}
            />
        );

        const deleteButton = screen.getByTestId("delete-button-2");
        fireEvent.click(deleteButton);

        expect(window.confirm).toHaveBeenCalledWith(
            "Are you sure you want to delete this job?"
        );
        expect(onDeleteMock).toHaveBeenCalledWith(mockJobs[1].id);
    });

    it("does not call onDelete when Delete button is clicked and user cancels", () => {
        const onDeleteMock = jest.fn();
        // Override window.confirm to simulate a cancel action
        jest.spyOn(window, "confirm").mockImplementation(() => false);

        render(
            <JobsTable
                jobs={mockJobs}
                onEdit={jest.fn()}
                onDelete={onDeleteMock}
            />
        );

        const deleteButton = screen.getByTestId("delete-button-2");
        fireEvent.click(deleteButton);

        expect(window.confirm).toHaveBeenCalledWith(
            "Are you sure you want to delete this job?"
        );
        expect(onDeleteMock).not.toHaveBeenCalled();
    });


});
