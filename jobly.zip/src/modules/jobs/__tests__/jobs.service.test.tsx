/**
 * @file src/modules/jobs/__tests__/jobs.service.test.ts
 */

import {CreateJobDto, JobDto, JobsService, UpdateJobDto} from "../jobs.service";
import {LocationEnum} from "../schema";

global.fetch = jest.fn();



// Mock data
const mockJob: CreateJobDto = {
  title: "Software Engineer",
  description: "Developing software",
  salary: 100000,
  is_active: true,
  location: LocationEnum.Enum.Onsite,
};

const mockUpdatedJob: UpdateJobDto = {
  id: 1,
  title: "Senior Software Engineer",
  description: "Developing and leading software projects",
  salary: 120000,
  is_active: true,
  location: LocationEnum.Enum.Remote,
    created_at: new Date(),
    updated_at: new Date(),
};

const mockJobDto: JobDto = {
  id: 2,
  title: "Software Engineer",
  description: "Developing software",
  salary: 100000,
  is_active: true,
  location: LocationEnum.Enum.Hybrid,
  created_at: new Date(),
  updated_at: new Date(),
};

describe("JobsService", () => {
  let service: JobsService;

  beforeEach(async () => {
    service = new JobsService();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should create a job successfully", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: jest
        .fn()
        .mockResolvedValue({ message: "Job created successfully" }),
    });

    const result = await service.createJob(mockJob);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/jobs"), {
      method: "POST",
      body: JSON.stringify(mockJob),
      headers: {
        "Content-Type": "application/json",
      },
    });
    expect(result).toEqual({ message: "Job created successfully" });
  });

  it("should update a job successfully", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
      json: jest
        .fn()
        .mockResolvedValue({ message: "Job updated successfully" }),
    });

    const result = await service.updateJob(1, mockUpdatedJob);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/jobs"), {
      method: "PUT",
      body: JSON.stringify(mockUpdatedJob),
      headers: {
        "Content-Type": "application/json",
      },
    });
    expect(result).toEqual({ message: "Job updated successfully" });
  });

  it("should delete a job successfully", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
      json: jest
        .fn()
        .mockResolvedValue({ message: "Job deleted successfully" }),
    });

    const result = await service.deleteJob(1);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/jobs?id="), {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      }
    });
    expect(result).toEqual({ message: "Job deleted successfully" });
  });

  it("should return a list of jobs", async () => {
    const mockJobs: JobDto[] = [mockJobDto];

    (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
      json: jest.fn().mockResolvedValue(mockJobs),
    });

    const result = await service.getJobs();
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/jobs"));
    expect(result).toEqual(mockJobs);
  });
});
