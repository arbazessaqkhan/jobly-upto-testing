// src/modules/jobs/components/JobsTable.tsx
"use client";

import React from "react";
import { JobDto } from "../jobs.service";

type Props = {
    jobs: JobDto[];
    onEdit: (job: JobDto) => void;
    onDelete: (id: number) => void;
};

export default function JobsTable({ jobs, onEdit, onDelete }: Props) {
    return (
        <table className="table table-striped table-bordered">
            <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Activated</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            {jobs.map((job) => (
                <tr key={job.id} data-testid={`job-row-${job.id}`}>
                    <td data-testid={`job-title-${job.id}`}>{job.title}</td>
                    <td data-testid={`job-description-${job.id}`}>{job.description}</td>
                    <td data-testid={`job-location-${job.id}`}>{job.location}</td>
                    <td data-testid={`job-salary-${job.id}`}>{job.salary}</td>
                    <td data-testid={`job-active-${job.id}`}>
                        {!job.is_active ? "Yes" : "No"}
                    </td>
                    <td data-testid={`job-created-${job.id}`}>
                        {new Date(job.created_at).toLocaleDateString()}
                    </td>
                    <td data-testid={`job-updated-${job.id}`}>
                        {new Date(job.updated_at).toLocaleDateString()}
                    </td>
                    <td>
                        <button
                            className="btn btn-primary me-2"
                            data-testid={`edit-button-${job.id}`}
                            data-bs-toggle="modal"
                            data-bs-target="#formModal"
                            onClick={() => {
                                if (
                                    window.confirm("Are you sure you want to delete this job?")
                                ) {
                                    onDelete(job.id);
                                }
                            }}

                        >
                            Edit
                        </button>
                        <button
                            className="btn btn-danger"
                            data-testid={`delete-button-${job.id}`}
                            onClick={() => onEdit(job)}

                        >
                            Delete
                        </button>
                    </td>
                </tr>
            ))}
            </tbody>
        </table>
    );
}
